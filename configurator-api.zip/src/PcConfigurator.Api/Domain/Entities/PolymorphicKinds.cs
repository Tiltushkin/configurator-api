namespace PcConfigurator.Api.Domain.Entities;

public enum CoolingKind { AirCooling, Szo }
public enum HddKind { Hdd2_5, Hdd3_5 }